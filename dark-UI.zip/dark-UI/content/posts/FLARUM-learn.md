---
title: "Flarum backup"
date: 2023-06-08T20:16:58+01:00
lastmod: 2023-06-08T20:16:58+01:00
subTitle: ""
description: "备份记录，主要是记录所有用到的扩展库，便于以后查找"
draft: false
featured: true
type: posts
label: "orginal"
author: tothemoon
tags: ["Tutorial"]
categories: ["Flarum"]
cover:
    position: <left,right>
    image: "null"
    alt: "<alt text>"
    caption: "<text>"
---


## 插件address

https://extiverse.com/


## 记录一下可能需要使用到的插件



https://extiverse.com/extension/acpl/mobile-tab

https://extiverse.com/extension/fof/custom-footer

https://extiverse.com/extension/askvortsov/flarum-categories

https://extiverse.com/extension/fof/stopforumspam

https://extiverse.com/extension/v17development/flarum-blog

https://extiverse.com/extension/blomstra/usercard-stats

https://extiverse.com/extension/justoverclock/custom-html-widget

https://extiverse.com/extension/nearata/flarum-ext-signup-confirm-password

https://extiverse.com/extension/sycho/flarum-advanced-extension-categories
https://extiverse.com/extension/swaggymacro/only-starter

https://extiverse.com/extension/datlechin/flarum-scroll-buttons

https://extiverse.com/extension/pattinsonfuture/lang-traditional-chinese

https://extiverse.com/extension/moerio/mixture

https://extiverse.com/extension/askvortsov/flarum-categories

https://extiverse.com/extension/fof/byobu
https://extiverse.com/extension/v17development/flarum-user-badges

## 测试地址

http://www.youngbird97.top/


教程正在updating，此篇仅为备忘录