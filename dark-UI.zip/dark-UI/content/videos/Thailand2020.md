---
title: "泰国旅行🇹🇭2020-怀念没有疫情的日子"
date: 2023-04-29T14:58:07+01:00
subTitle: ""
description: "希望明年能再去一次，因为短短的一周实在是不够尽兴"
draft: false
type: posts
layout: videos
label: "travle"
author: tothemoon
tags: ["Travle","Tailand"]
categories: ["Travle"]
image: "https://i.imgur.com/Kwt3poD.png["
---

<iframe height=498 width="100%" src="https://player.youku.com/embed/XNDgxNjkxMDYxMg==" frameborder=0 allowfullscreen></iframe>