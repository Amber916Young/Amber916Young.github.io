---
title: "Home"
date: 2023-03-07T22:54:08Z
draft: false
typed_names: Java Developer, Flutter Developer, Photographer
display_name: YOUNG Hello
layout: "index"
---



Hello, I'm yejia Yang

I'm a backend developer, currently work for a startup company

I like learning something new.