---
title: "About me"
date: 2023-03-08T20:48:29Z
draft: false
type: about
layout: "about"
avatar: 
---

# Hello, I'm xxx
## kdm
<p style=" color:red ">
I come from Poland, and I'm a UI designer with some coding skills. I'm also interested in UX, as I believe that every product should be usable, accessible, profitable, and let users perform core tasks without any friction. I keep designing every day to polish my skills. Besides designing and coding, I love learning foreign languages. I graduated in 2021 in English Studies at the University of Opole, and now I'm learning German and Czech.
</p>

